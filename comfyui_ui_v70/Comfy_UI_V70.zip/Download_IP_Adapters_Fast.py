from huggingface_hub import snapshot_download
snapshot_download(repo_id="MonsterMMORPG/SECourses_Patreon_Rocks",local_dir="ComfyUI")